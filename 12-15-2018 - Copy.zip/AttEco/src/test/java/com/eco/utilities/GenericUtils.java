package com.eco.utilities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.eco.testCases.BaseClass;

public class GenericUtils extends BaseClass {

	// Click Method
	public void click(By elementBy) {
		System.out.println("click");
		WebDriverWait wait;
		wait = new WebDriverWait(driver, 20);

		// waitVisibility(elementBy);
		try {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
			Thread.sleep(200);
			driver.findElement(elementBy).click();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void click(WebElement elementBy) {
		System.out.println("click");
		WebDriverWait wait;
		wait = new WebDriverWait(driver, 20);

		// waitVisibility(elementBy);
		try {
			wait.until(ExpectedConditions.visibilityOf(elementBy));
			wait.until(ExpectedConditions.elementToBeClickable(elementBy));
			elementBy.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void sendKeys(By elementBy, String value) {
		System.out.println("click");
		WebDriverWait wait;
		wait = new WebDriverWait(driver, 30);

		// waitVisibility(elementBy);
		try {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));

			driver.findElement(elementBy).sendKeys(value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void sendKeys(WebElement we, String value) {
		System.out.println("click");
		WebDriverWait wait;
		wait = new WebDriverWait(driver, 30);

		// waitVisibility(elementBy);
		try {
			wait.until(ExpectedConditions.visibilityOf(we));
			we.sendKeys(value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

//	// select item from list
//	public void selectItemFromList(By elementBy, String itemToSelect) {
//		boolean srchStringFound = false;
//		try {
//			WebDriverWait wait;
//			wait = new WebDriverWait(driver, 10);
//			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
//
//			System.out.println("select item locator =  " + itemToSelect);
//			Select selectionList = new Select(driver.findElement(elementBy));
//
//			List<WebElement> options = selectionList.getOptions();
//			for (WebElement option : options) {
//				if (option.getText().contentEquals(itemToSelect)) {
//					BaseClass.logger.info("Found the option " + itemToSelect);
//					srchStringFound = true;
//					break;
//				}
//				System.out.println(option.getText()); // Prints "Option", followed by "Not Option"
//			}
//			if (srchStringFound) {
//				selectionList.selectByValue(itemToSelect);
//			}
//		} catch (Exception ex) {
//			BaseClass.logger.info(ex.getMessage());
//			System.out.println(ex.getMessage());
//		}
//	}
	 //select item from list
    public void selectItemInList (String itemToSelect) {
    	
        //waitVisibility(driver.findElement(By.id("msCatalogDropdown"));
        System.out.println("select item locator =  msCatalogDropdown");     
        Select msCatalogOption = new Select(driver.findElement(By.id("msCatalogDropdown")));
    	msCatalogOption.selectByValue(itemToSelect);        
    }
	
    
    //select item from list
    public void selectItemFromList (By elementBy,String itemToSelect)
    {
    	boolean srchStringFound=false;  	
    	try
    	{
    		 	WebDriverWait wait;
        	 	wait = new WebDriverWait(driver,10);
        	 	wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
        	 	
		        System.out.println("select item locator =  " + itemToSelect);     
		        Select selectionList = new Select(driver.findElement(elementBy));	      		      
		        
		        List<WebElement> options = selectionList.getOptions();
		        for (WebElement option : options)
		        {
		        	if(option.getText().contentEquals(itemToSelect))
		        	{
		        		BaseClass.logger.info("Found the option " + itemToSelect);	
		        		srchStringFound= true;
		        		break;
		        	}
		            System.out.println(option.getText()); //Prints "Option", followed by "Not Option"
		        }
		        if (srchStringFound) 
		        {
		        	  selectionList.selectByValue(itemToSelect);  
		        }		        		        
    	}
    	catch(Exception ex) {
    		BaseClass.logger.info(ex.getMessage());
    		System.out.println(ex.getMessage());
    	}
    }
    

    

}
