package com.eco.pageObjects;


import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import com.eco.testCases.BaseClass;
import com.eco.utilities.XLUtils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class LoginPage extends BaseClass
{

	WebDriver ldriver;
	
	public LoginPage(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
		//BasePage bp = new BasePage(ldriver);
	}
		
	/*@FindBy(name="login")
	@CacheLookup
	WebElement loginButton;
	
	@FindBy(name="userid")
	@CacheLookup
	WebElement txtUserName;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(name="btnSubmit")
	@CacheLookup
	WebElement btnLogin;*/
	
	
	@FindBy(xpath="/html/body/div[3]/div/ul/li[15]/a")
	@CacheLookup
	WebElement lnkLogout;
	
	
	
	public void setUserName(String uname)
	{
		try
		{
					
			System.out.println( "number of user id elements found = " + ldriver.findElements(By.name("userid")).size());
			if(ldriver.findElements(By.name("userid")).size() > 0)
				ldriver.findElement(By.name("userid")).sendKeys(uname);
			else
				BaseClass.logger.info("could not find the user name element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void setPassword(String pwd)
	{
		try
		{
					
			System.out.println( "number pwd = " + ldriver.findElements(By.name("password")).size());
			if(ldriver.findElements(By.name("password")).size() > 0)
				ldriver.findElement(By.name("password")).sendKeys(pwd);
			else
				BaseClass.logger.info("could not find the password element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	public void clickSubmit()
	{
		try {
			System.out.println( "number of buttonsubmit found = " + ldriver.findElements(By.name("btnSubmit")).size());
			if(ldriver.findElements(By.name("btnSubmit")).size() > 0)
			{
				System.out.println( "if number of buttonsubmit");
				ldriver.findElement(By.name("btnSubmit")).click();
			}
			else
				BaseClass.logger.info("could not find the login button");

		Thread.sleep(5000);
	} catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	public void clickLoginButton()
	{
		System.out.println("click on Login Button");
		
		try {
				System.out.println( "number of login buttons found = " + ldriver.findElements(By.id("login")).size());
				if(ldriver.findElements(By.id("login")).size() > 0) {
					ldriver.findElement(By.id("login")).click();
					System.out.println( "After click login button");
				}
				else
					BaseClass.logger.info("could not find the login button");
	
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	public void clickLoginSuccessButton()
	{
		System.out.println("click on successOK Button");
		
		try {
				System.out.println( "number of successOK buttons found = " + ldriver.findElements(By.name("successOK")).size());
				if(ldriver.findElements(By.name("successOK")).size() > 0) {
					ldriver.findElement(By.name("successOK")).click();
					System.out.println( "After click successOK button");
				}
				else
					BaseClass.logger.info("could not find the successOK button");
	
			Thread.sleep(3000);
		} catch (Exception e) {
			System.out.println( "After click successOK exception ");
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}	
	
	public void clickLogout()
	{
		try {
		System.out.println( "logout");
		ldriver.findElement(By.name("successOK")).click();
		Thread.sleep(5000);
		ldriver.findElement(By.className("caret")).click();
		System.out.println( "caret");
		Thread.sleep(5000);
		WebDriverWait wait;
		
		wait = new WebDriverWait(ldriver,10);
		wait.until(ExpectedConditions.elementToBeClickable(ldriver.findElement(By.className("fa-sign-out"))));
		ldriver.findElement(By.className("fa-sign-out")).click();
		
		//System.out.println( "logout button size " + ldriver.findElements(By.xpath("//*[contains(text(), ' Logout')]")).size() ); 
		//WebElement elem = ldriver.findElement(By.xpath(".//*[text()='Logout'"));	 

		// This will enable this element if element is invisible      		 
		//String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";
		 
		// Execute the Java Script for the element which we find out
		//((JavascriptExecutor) ldriver).executeScript(js, elem);
		 
		// Click on element		 
		//elem.click();
		
		

		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}
	
	public void loginTest(String user , String pwd)
	{
		logger.info("URL is opened");
		
		LoginPage lp=new LoginPage(driver);
		
		try {
			Thread.sleep(3000);
		
		
		lp.clickLoginButton();
		logger.info("click on login button");
			
		Thread.sleep(2000);
		
		System.out.println(" ------username cell data from excel" );
		
		System.out.println("username cell data from excel" + user);
		System.out.println(pwd);
		
		lp.setUserName(user);
		logger.info("Entered username");
		
		System.out.println("username cell data from excel" + pwd);
		lp.setPassword(pwd);
		logger.info("Entered password");
		
		lp.clickSubmit();
		
		Thread.sleep(5000);
		System.out.println("title = "+driver.getTitle());
		
		if(driver.getTitle().contains("Log On Successful"))
		{
			Assert.assertTrue(true);
			logger.info("Login test passed");			
			
		}
		else
		{				
			captureScreen(driver,"loginTest");
			Assert.assertTrue(false);
			logger.info("Login test failed");				
		}		
		clickLoginSuccessButton();
		//lp.clickLogout();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}









