package com.eco.pageObjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.eco.testCases.BaseClass;
import com.eco.testCases.*;

public class SourceCode {
	
	WebDriver ldriver;
    public WebDriver driver;
    public WebDriverWait wait;

	public SourceCode(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);		
	}
	
	public boolean addSourceCode()
	{
		boolean result=false;				
		return result;
	}
	
	  //Write Text
    public void writeText (By elementBy, String text) {
        waitVisibility(elementBy);
        System.out.println("sendkeys");
        ldriver.findElement(elementBy).sendKeys(text);
    }
 
    //Write Text
    public void writeTextSimple (String locator, String text)
    {
      try
      {
        System.out.println("sendkeys");
        if(ldriver.findElements(By.id(locator)).size() > 0)
			ldriver.findElement(By.id(locator)).sendKeys(text);
        else
        	System.out.println( locator +"Element not found");     
       
      }
      catch(Exception ex)
      {
    	  System.out.println(ex.getMessage());
    	  ex.printStackTrace();
      }
    }
    
    //Read Text
    public String readText (By elementBy) {
        waitVisibility(elementBy);
        System.out.println("readText");
        return ldriver.findElement(elementBy).getText();
    }    
    
    //Assert
    public void assertEquals (By elementBy, String expectedText) {
        waitVisibility(elementBy);
        Assert.assertEquals(readText(elementBy), expectedText);
 
    }
 
    //Wait Wrapper Method
    public void waitVisibility(By elementBy) {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
    }
 
    
    public void clickLinkText()
    {
    	try
    	{
    		
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    		ex.printStackTrace();
    	}
    }
    
    public void clickLinkTextTemplate()
    {
    	try
    	{
    		
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    		ex.printStackTrace();
    	}
    }
    //Click Method
    public void click (By elementBy) {
    	try
    	{
    		System.out.println("click");
    		WebDriverWait wait;	    	
	    	wait = new WebDriverWait(ldriver,30);
	    	wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
	        ldriver.findElement(elementBy).click();
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    		ex.printStackTrace();
    	}
    }
    
    
    //Click Method
    public void hoverToElement (By elementBy) {
    	try
    	{
    		 waitVisibility(elementBy);
    		 WebElement ele = ldriver.findElement(elementBy);
    		  //Create object 'action' of an Actions class
    		  Actions action = new Actions(ldriver);
    		  //Mouseover on an element
    		  action.moveToElement(ele).click();   		
	    	 
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    }
         
    
  //select item from list
    public void selectItemFromList (By elementBy,String itemToSelect) {
    	boolean srchStringFound=false;   	
    	try
    	{
    		 	WebDriverWait wait;
        	 	wait = new WebDriverWait(ldriver,10);
        	 	wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
        	 	
		        System.out.println("select item locator =  " + itemToSelect);     
		        Select selectionList = new Select(ldriver.findElement(elementBy));	      		      
		        int index=1;
		        List<WebElement> options = selectionList.getOptions();
		        for (WebElement option : options)
		        {
		        	if(option.getText().contains(itemToSelect))
		        	{
		        		BaseClass.logger.info("Found the option " + itemToSelect);	
		        		selectionList.selectByIndex(index); 
		        		break;
		        	}
		            System.out.println(option.getText()); //Prints "Option", followed by "Not Option"
		        }
		       
		        index++;
    	}
    	catch(Exception ex) {
    		BaseClass.logger.info(ex.getMessage());
    		System.out.println(ex.getMessage());
    	}
    }
	

}
