package com.eco.pageObjects;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.eco.testCases.BaseClass;
import com.eco.utilities.GenericUtils;

public class createPipeline extends GenericUtils{
	
	WebDriver ldriver;
	String pline;
	
	@FindBy(xpath="//button[@id='create-pipeline-select']")
	WebElement buttonCreatePipeline;
	
	@FindBy(xpath="//a[contains(.,'CDP Workflow')]")
	WebElement linkCDPWorkFlow;
	
	@FindBy(xpath="//a[contains(.,'CDP Dynamic Workflow')]")
	WebElement linkCDPDynamicWorkflow;
	                                                
	@FindBy(xpath="//a[contains(.,'Jenkins Automated Deployment Workflow')]")
	WebElement linkJenkinsAutomatedDeploymentWorkflow;
	
	@FindBy(xpath="//button[@id='createPipelineSubmitBtn'][contains(text(),'Create Pipeline')]")
	WebElement linkCreatePipeLineButton;
	
	
	/**
	 * @author Vp1515                                             
	 * @param strWorkFlowName
	 */
	public void selectWorkFlow(String strWorkFlowName) {
		click(buttonCreatePipeline);
		if(strWorkFlowName.contains("CDP Workflow"))
			click(linkCDPWorkFlow);
		else if(strWorkFlowName.contains("CDP Dynamic Workflow"))
			click(linkCDPDynamicWorkflow);
		else if(strWorkFlowName.contains("Jenkins Automated Deployment Workflow"))
			click(linkJenkinsAutomatedDeploymentWorkflow);
		else
			click(By.xpath("//a[contains(.,'"+strWorkFlowName+"')]"));
	}
	
	public createPipeline(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	public void setUserName(String uname , WebDriver ldriver)
	{
		try
		{
					
			System.out.println( "number of user id elements found = " + ldriver.findElements(By.name("userid")).size());
			if(ldriver.findElements(By.name("userid")).size() > 0)
				ldriver.findElement(By.name("userid")).sendKeys(uname);
			else
				BaseClass.logger.info("could not find the user name element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void setPipelineName(String pipeLineName)
	{
		try
		{
			
			System.out.println("New Pipeline name =  "+ pipeLineName);
			System.out.println( "number pwd = " + ldriver.findElements(By.id("pipelineNameInput")).size());
			if(ldriver.findElements(By.id("pipelineNameInput")).size() > 0)
				ldriver.findElement(By.id("pipelineNameInput")).sendKeys(pipeLineName);
			else
				BaseClass.logger.info("could not find the pipelineNameInput element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	public void setSearchPipelineName(String pipeLneName)
	{
		try
		{			
			System.out.println( "number pwd = " + ldriver.findElements(By.id("searchinput")).size());
			if(ldriver.findElements(By.id("searchinput")).size() > 0)
				ldriver.findElement(By.id("searchinput")).sendKeys(pipeLneName);
			else
				BaseClass.logger.info("could not find the pipelineNameInput element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	public void setBranchName(String branchName)
	{
		try
		{				
			System.out.println( "number pwd = " + ldriver.findElements(By.id("pipelineBranchInput")).size());
			if(ldriver.findElements(By.id("pipelineBranchInput")).size() > 0)
				ldriver.findElement(By.id("pipelineBranchInput")).sendKeys(branchName);
			else
				BaseClass.logger.info("could not find the branchName element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}

	
    public void setDevopJitHubNameName(String uid)
	{
		try
		{			
			System.out.println( "number pwd = " + ldriver.findElements(By.xpath("//input[contains(@id,'gitHookUserName')]")).size());
			if(ldriver.findElements(By.xpath("//input[contains(@id,'gitHookUserName')]")).size() > 0)
				ldriver.findElement(By.xpath("//input[contains(@id,'gitHookUserName')]")).sendKeys(uid);
			else
				BaseClass.logger.info("could not find the dev-pipeline-jenkins|global|gitHookUserName element");		
		}			
	
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}

    
    public void setDevopJitHubNamePwd(String pwd)
   	{
   		try
   		{
   					
   			System.out.println( "number pwd = "  + pwd + ldriver.findElements(By.xpath("//input[contains(@id,'gitHookPassword')]")).size());
   			if(ldriver.findElements(By.xpath("//input[contains(@id,'gitHookPassword')]")).size() > 0)
   				ldriver.findElement(By.xpath("//input[contains(@id,'gitHookPassword')]")).sendKeys(pwd);
   			else
   				BaseClass.logger.info("could not find the gitHookPassword element");		
   		}			
   	
   		catch(Exception ex)
   		{
   			System.out.println(ex.getMessage());
   		}
   	}
     
    public void clickOnDevopsCredentialsSubmitButton()
  	{
  		System.out.println( "clickOnDevopsCredentialsSubmit" );
  		
  		try {
  				Thread.sleep(1000);
  				System.out.println( "number of clickCreatePipeLine found = " + ldriver.findElements(By.className("fa-arrow-right")).size());
  				if(ldriver.findElements(By.className("configSubmitBtn")).size() > 0)
  				{
  					System.out.println( "if number of clickCreatePipeLine");
  					ldriver.findElement(By.className("fa-arrow-right")).click();
  					System.out.println( "after configSubmitBtn");
  					Thread.sleep(1000);
  				}
  				else
  					BaseClass.logger.info("could not find the configSubmitBtn button");
  	
  				Thread.sleep(3000);
  			}
  			catch (Exception e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  	}

    
    
    public void clickOnCreateNewPipeLine2nd()
	{
		System.out.println( "clickOnCreateNewPipeLine2nd" );
		
		try {
				Thread.sleep(1000);
				System.out.println( "number of clickCreatePipeLine found = " + ldriver.findElements(By.className("createPipelineSubmitBtn")).size());
				if(ldriver.findElements(By.className("createPipelineSubmitBtn")).size() > 0)
				{
					System.out.println( "if number of clickCreatePipeLine");
//					ldriver.findElement(By.className("createPipelineSubmitBtn")).click();
					click(linkCreatePipeLineButton);
					System.out.println( "after clickCreatePipeLine");
					Thread.sleep(1000);
				}
				else
					BaseClass.logger.info("could not find the createPipelineSubmitBtn button");
	
				Thread.sleep(5000);
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	
	public void clickCreatePipeLine()
	{
		System.out.println( "clickCreatePipeLine" );
		
		try {
			Thread.sleep(1000);
			System.out.println( "number of clickCreatePipeLine found = " + ldriver.findElements(By.className("createBtn")).size());
			if(ldriver.findElements(By.className("createBtn")).size() > 0)
			{
				System.out.println( "if number of buttonsubmit");
				ldriver.findElement(By.className("createBtn")).click();
				System.out.println( "after buttonsubmit");
				Thread.sleep(1000);
			}
			else
				BaseClass.logger.info("could not find the login button");

			Thread.sleep(5000);
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	
	public  String randomString() 
  	{
  		String generatedString = RandomStringUtils.randomAlphabetic(4);
  		return generatedString;
  	}

}
