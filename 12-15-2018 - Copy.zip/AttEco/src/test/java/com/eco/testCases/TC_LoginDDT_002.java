package com.eco.testCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.*;

import com.eco.pageObjects.LoginPage;
import com.eco.utilities.XLUtils;

public class TC_LoginDDT_002 extends BaseClass
{
	
	
	
	@Test(dataProvider="LoginData", parameters = { "number-of-times" })
	public void loginDDT(String user,String pwd, String executeFlag) throws InterruptedException, IOException
	{
		

		try {
			if(executeFlag.contains("Y"))
			{
			
			logger.info("URL is opened");
			
			LoginPage lp=new LoginPage(driver);
			
			Thread.sleep(3000);
			
			lp.clickLoginButton();
			logger.info("click on login button");
				
			Thread.sleep(2000);
			
			System.out.println(" ------username cell data from excel" );
			
			System.out.println("username cell data from excel" + user);
			System.out.println(pwd);
			
			lp.setUserName(user);
			logger.info("Entered username");
			
			System.out.println("username cell data from excel" + pwd);
			lp.setPassword(pwd);
			logger.info("Entered password");
			
			lp.clickSubmit();
			
			Thread.sleep(5000);
			System.out.println("title = "+driver.getTitle());
			
			if(driver.getTitle().contains("Log On Successful"))
			{
				Assert.assertTrue(true);
				logger.info("Login test passed");			
				
			}
			else
			{				
				captureScreen(driver,"loginTest");
				Assert.assertTrue(false);
				logger.info("Login test failed");				
			}		
			
			//lp.clickLogout();
			
			}
			
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}
	
	
	public boolean isAlertPresent() //user defined method created to check alert is presetn or not
	{
		try
		{
		driver.switchTo().alert();
		return true;
		}
		catch(NoAlertPresentException e)
		{
			return false;
		}
		
	}
	
	
	
	
}
