package com.eco.testCases;
import java.io.IOException;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.eco.pageObjects.LoginPage;
import com.eco.pageObjects.createPipeline;
import com.eco.testData.DataProviderClass;
import com.eco.utilities.XLUtils;
import com.eco.utilities.ReadConfig;;

public class TC_CreatePipeline extends BaseClass
{
		
	@Test(priority=1)
	public void initializeCreatePipeline()
	{
		LoginPage lp = new 	LoginPage(driver);
		ReadConfig rc = new ReadConfig();
		try {
			System.out.println("Excel data path"+rc.getTestDataExcelPath());
				lp.loginTest(XLUtils.getCellData(System.getProperty("user.dir")+rc.getTestDataExcelPath(), "login", 1, 0),
					XLUtils.getCellData(System.getProperty("user.dir")+rc.getTestDataExcelPath(), "login", 1, 1));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test(dataProvider="CreatePipeline",priority=2)
	public void createPipeline(String name, String branch, String msCatalog) throws IOException 
	{
			try {
				
				System.out.println("Testing to see if reached 2::");
				createPipeline cp = new createPipeline(driver);
				cp.clickCreatePipeLine();
				logger.info("Click on create pipeline button ");
				
				String newPipelineName = "JPipeline"+randomString();
				cp.setPipelineName(newPipelineName);
				logger.info("The  set text to new pipeline name " + newPipelineName);
				cp.setBranchName("Master");
				logger.info("The  set text to branch Master");
						
				
				//cp.click(By.xpath("//button[@id='create-pipeline-select']"));
				cp.selectWorkFlow("CDP Workflow");
				
				//cp.selectItemFromList(By.id("msCatalogDropdown"),"1a15daba-6f00-48e4-bb42-e28bbde2f516");
				logger.info("The  select ms catalog");
				cp.clickOnCreateNewPipeLine2nd();
				logger.info("Click on create pipeline");
				Thread.sleep(3000);
				
				cp.setDevopJitHubNameName("userName");
				logger.info("Set user name for jit hub");
				
				cp.setDevopJitHubNamePwd("password");
				logger.info("CSet user password for jit hub");
				
				//***********************************************************************************
			
				//cp.click(By.className("add-configuration"));
				/*
				
				cp.click(By.xpath("//*[@id='deployments-developmentLoop']/div[1]/div/button"));
				logger.info("Click on add configuration button");
				
				cp.sendKeys(By.id("deployment-config-name"), "DCN"+ " " +randomString());
				logger.info("Set text value for Deployment Configuration Name");
				
				cp.click(By.id("globalConfirm"));
				logger.info("click on add button");
							
				
				cp.sendKeys(By.id("deploymentNotificationEmail|dev-pipeline-jenkins|Deployment_Notification_Email"), "vp1515@att.com");			
				logger.info("Select Deployment Notification Email");	
				
				cp.sendKeys(By.id("assignTo|dev-pipeline-jenkins|Request_Build"), "vp1515@att.com");			
				logger.info("Select Request Build Notification Email");
				
				
				cp.selectItemFromList(By.xpath("//*[@id='deployments-developmentLoop']/div[3]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div/div/select"), "Ecobuildserver");					
				logger.info("Select Trigger Jenkins Development Pipeline name");
				
				cp.sendKeys(By.id("assignTo|dev-pipeline-jenkins|Trigger_Jenkins_Development_Pipeline"), "vp1515@att.com");			
				logger.info("Set Trigger Jenkins Development Pipeline Notification Email");
				
				
				cp.selectItemFromList(By.className("deployment-attribute"), "Ecobuildserver");					
				logger.info("Select environment DropDown deployment-attribute name");
							
				
				cp.sendKeys(By.xpath("//*[@id='jobName|dev-pipeline-jenkins|Trigger_Jenkins_Development_Pipeline'"), "JJBName"+randomString());		
				logger.info("Set Trigger Jenkins Development Pipeline Notification Email");
			
				cp.click(By.id("configSubmitBtn"));
				logger.info("click on githook configSubmitBtn button");
				*/
				
				//***********************************************************************************
								
				cp.click(By.id("configSubmitBtn"));
				Thread.sleep(5000);	
				
				cp.setSearchPipelineName(newPipelineName);
				
				cp.click(By.id("pipelineSearchBtn"));				
				System.out.println("New pipeline name is "+ newPipelineName);
			
				System.out.println("searched pipeline result = "+ driver.findElement(By.xpath("//*[@id='processGroupList']/li/div/div[1]/span")).getAttribute("innerText"));
				
				if(driver.findElement(By.xpath("//*[@id='processGroupList']/li/div/div[1]/span")).getAttribute("innerText").trim().contains(newPipelineName))
				{
					System.out.println("passed if");
					Assert.assertTrue(true);
					logger.info("Create Pipeline test passed");
					Thread.sleep(2000);	
				}
				else
				{
					captureScreen(driver,"CreatePipeline");
					Assert.assertTrue(false);
					logger.info("Create Pipeline test failed");
				}		
				Thread.sleep(3000);	
				System.out.println("Text deployment search ="+ driver.findElement(By.id("module-header")).getAttribute("innerText"));
			
			}
			catch ( Exception ex)
			{
				System.out.println(ex.getMessage());
			}	
	}
	
	
	
	@DataProvider(name="CreatePipeline")
	String [][] getData() throws IOException
	{
		String path=System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls";
		int rownum=XLUtils.getRowCount(path, "pipeline");
		int colcount=XLUtils.getCellCount(path,"pipeline",1);
		
		String logindata[][]=new String[rownum][colcount];
		
		for(int i=1;i<=rownum;i++)
		{
			for(int j=0;j<colcount;j++)
			{
				logindata[i-1][j]=XLUtils.getCellData(path,"pipeline", i,j);//1 0
				
			}
				
		}
	return logindata;
	}
	
	public  String randomString() 
  	{
  		String generatedString = RandomStringUtils.randomAlphabetic(4);
  		return generatedString;
  	}

	
}
