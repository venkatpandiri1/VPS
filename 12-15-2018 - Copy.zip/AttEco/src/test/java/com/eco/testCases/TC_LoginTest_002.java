package com.eco.testCases;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.eco.pageObjects.LoginPage;
import com.eco.pageObjects.createPipeline;
import com.eco.utilities.XLUtils;


public class TC_LoginTest_002 extends BaseClass
{
	
	@Test
	public void loginTest() throws IOException 
	{
		try {
				logger.info(" TC_LoginTest_002 URL is opened");
				
				LoginPage lp=new LoginPage(driver);
				
				Thread.sleep(5000);
				
				lp.clickLoginButton();
				logger.info("click on login button");
				
				
				Thread.sleep(500);
				
				System.out.println(" ------username cell data from excel" );
				
				System.out.println("username cell data from excel" + XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 0));
				System.out.println(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 1));
				
				lp.setUserName(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 0));
				logger.info("Entered username");
				
				
				lp.setPassword(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 1));
				logger.info("Entered password");
				
				lp.clickSubmit();
				logger.info("Click submit button");
				Thread.sleep(2000);						
				
				lp.clickLoginSuccessButton();
				logger.info("Click success ok button");
				Thread.sleep(1000);
				
				createPipeline cp = new createPipeline(driver);
				logger.info("Starting the create pipeline test");
				cp.clickCreatePipeLine();
				
				//lp.clickLoginSuccessButton();
				
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Error fom login test " + e.getMessage());
		}
		
	}
	
		
}

