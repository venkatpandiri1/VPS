package com.eco.testCases;
import utils.ExtentReports.*;


import java.io.IOException;


import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.Reporter;

import com.eco.pageObjects.LoginPage;
import com.eco.utilities.XLUtils;
import com.relevantcodes.extentreports.LogStatus;

import utils.ExtentReports.ExtentTestManager;


public class TC_LoginTest_001 extends BaseClass
{

	@Test
	public void loginTest() throws IOException 
	{
		try {
				logger.info("URL is opened");
				
				LoginPage lp=new LoginPage(driver);
				
				Thread.sleep(5000);
				
				lp.clickLoginButton();
				logger.info("click on login button");
				Reporter.log("---Login button click--");
				ExtentTestManager.getTest().log(LogStatus.PASS, "Click login button", "details");
				ExtentTestManager.getTest().log(LogStatus.INFO, "Click login button");
				
				
				Thread.sleep(500);
				
				System.out.println(" ------username cell data from excel" );
				
				System.out.println("username cell data from excel" + XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 0));
				System.out.println(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 1));
				
				lp.setUserName(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 0));
				logger.info("Entered username");
				
				ExtentTestManager.getTest().log(LogStatus.PASS, "enter user name", "vp1515");
				
				
				lp.setPassword(XLUtils.getCellData(System.getProperty("user.dir")+"/src/test/java/com/eco/testData/LoginData.xls", "login", 1, 1));
				logger.info("Entered password");
				
				lp.clickSubmit();
				logger.info("Click on submit button");
				Thread.sleep(2000);
				ExtentTestManager.getTest().log(LogStatus.PASS, "Click submit button", "OK");
				
				System.out.println("title = "+driver.getTitle());
				if(driver.getTitle().contains("Log On Successful"))
				{
					Assert.assertTrue(true);
					logger.info("Login test passed");
				}
				else
				{
					 ExtentTestManager.getTest().setDescription("Invalid Login Scenario with wrong username and password.");
					captureScreen(driver,"loginTest");
					Assert.assertTrue(false);
					logger.info("Login test failed");
				}
				
				lp.clickLoginSuccessButton();
				logger.info("Click on login success button");
				Thread.sleep(5000);				
				
		
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
		
}
