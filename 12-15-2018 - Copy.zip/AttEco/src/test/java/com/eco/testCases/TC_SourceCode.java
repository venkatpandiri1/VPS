package com.eco.testCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.eco.pageObjects.SourceCode;

public class TC_SourceCode  extends BaseClass
{
	public void login()
	{
		TC_LoginTest_001 logintc = new TC_LoginTest_001();;
		try
		{
			logintc.loginTest();
		}
		catch ( Exception ex)
		{
			System.out.println(ex.getMessage());
		}						
	}
		
	
	@Test
	public void addSourceCode() throws IOException 
	{
		
		try
		{		
			login();
						
			System.out.println("after login");
			SourceCode sc = new SourceCode(driver);
			
			Thread.sleep(3000);		
			
			sc.selectItemFromList(By.id("mots-dropdown"), "AUTOTEAMSPACE2");
			Thread.sleep(5000);
			
			sc.click(By.className("minifyme"));
			/*if (driver.findElements(By.className("minifyme")).size() > 0)
			{
				logger.info("found minifyme ");
				driver.findElement(By.className("minifyme")).click();
			} */
						
			Thread.sleep(5000);
			/*if (driver.findElement(By.linkText("Administration")).isDisplayed())
				driver.findElement(By.linkText("Administration")).click(); */
			sc.click(By.linkText("Administration")); 
			Thread.sleep(2000);
			WebElement elementToClick;
			if (driver.findElements(By.linkText("System Connections")).size() >0)
			{
				 elementToClick = driver.findElement(By.linkText("System Connections"));
				// Scroll the browser to the element's Y position
				((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+elementToClick.getLocation().y+")");
				// Click the element
				elementToClick.click();
			}
			//if (driver.findElement(By.linkText("System Connections")).isDisplayed())
				//driver.findElement(By.linkText("System Connections")).click();
			//sc.click(By.linkText("System Connections"));
			Thread.sleep(5000);
			// Find an element

			elementToClick = driver.findElement(By.className("global-source-code-modal-btn"));
			// Scroll the browser to the element's Y position
			((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+elementToClick.getLocation().y+")");
			// Click the element
			elementToClick.click();

		
			Thread.sleep(500);
			if(driver.findElements(By.id("source-code-modal-name-input")).size() > 0)
				driver.findElement(By.id("source-code-modal-name-input")).sendKeys("test");
				
			//sc.writeTextSimple("source-code-modal-name-input", "test");
			Thread.sleep(500);
			//if(driver.findElements(By.id("source-code-modal-url-input")).size() > 0)
			//	driver.findElement(By.id("source-code-modal-url-input")).sendKeys("test");
			
			sc.writeTextSimple("source-code-modal-url-input", "test0");
			Thread.sleep(500);
			//if(driver.findElements(By.id("source-code-modal-url-input")).size() > 0)
			//	driver.findElement(By.id("source-code-modal-url-input")).sendKeys("test");
			
				
			sc.writeTextSimple("source-code-modal-username-input", "test2");
			Thread.sleep(500);
			sc.writeTextSimple("source-code-modal-password-input", "test3");
			
			Thread.sleep(500);
			
			if(driver.findElements(By.id("source-code-modal-submit-btn")).size() > 0)
				driver.findElement(By.id("source-code-modal-submit-btn")).click();
			
			Thread.sleep(5000);

			
			//Thread.sleep(3000);
			/*
			 * 
			 * driver.findElement(By.linkText("Administration")).click()
			driver.findElement(By.linkText("System Connections")).click()
			driver.findElement(By.className("global-source-code-modal-btn")).click()
			driver.findElement(By.id("source-code-modal-name-input")).sendKeys("test")
			driver.findElement(By.id("source-code-modal-url-input")).sendKeys("test")
			driver.findElement(By.id("source-code-modal-username-input")).sendKeys("test")
			driver.findElement(By.id("source-code-modal-password-input")).sendKeys("test")
			driver.findElement(By.id("source-code-modal-submit-btn")).click()
			driver.findElement(By.linkText("Click here to learn more about System Connections")).click()
			driver.findElement(By.linkText("Having issues with authentication? More info here.")).click()
			driver.findElement(By.id("source-code-modal-alert")).getText()
			
			driver.findElement(By.id("source-code-mechid-checkbox")).click()
			edit  View/Edit Teamspace MechID
			driver.findElement(By.className("configure-teamspace-btn")).click()
			 */

			if (driver.findElements(By.className("fa-cogs")).size() > 0)
			{
				logger.info("found Administration  size " + driver.findElements(By.className("fa-cogs")).size() );
				driver.findElement(By.className("fa-cogs")).click();
			}
			sc.hoverToElement(By.className("Administration"));
			logger.info("Click on Administration cog wheel ");
			Thread.sleep(3000);
			
			if (driver.findElements(By.linkText("System Connections")).size() > 0)
			{
				logger.info("found linktest ");
				driver.findElement(By.linkText("System Connections")).click();
			} 
										
			sc.click(By.xpath("//*[@id=\'left-panel\']/nav/ul/li[5]/ul/li[2]/a/span"));
			logger.info("Click on System connections");
			Thread.sleep(3000);
			
			sc.click(By.className("btn-primary btn-xs pull-right global-source-code-modal-btn"));
			logger.info("Click on Add source code button");
			Thread.sleep(3000);
			
			logger.info(sc.readText(By.className("modal-title")));
			String title = sc.readText(By.className("modal-title"));
			sc.assertEquals(By.className("modal-title"), "Add Source Code Connection");			
			Thread.sleep(3000);
		
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage() );
			ex.printStackTrace();
		}
		
	}
}
